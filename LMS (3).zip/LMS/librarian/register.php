<?php
include '../dbcon.php';
session_start();
if (isset($_SESSION['librarian_signin'])) {
    header('Location:index.php');
}
if (isset($_POST['register'])) {
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];

$phone = $_POST['phone'];
$photo = explode('.',$_FILES['pp']['name']);
    
    $photo = end($photo);
        

    $photo_name = $username.".".$photo;

//Form Validation:
if (strlen($username)>'7') {
    
}
else{
    $username_l = "";
}
if (strlen($password)>'7') {
  $password = md5($password); 

}
else{
    $password_l ="";
}
//Match input Email with Databases' Email     
        $email_check = mysqli_query($con, "SELECT * FROM librarian WHERE email = '$email';");

        if (mysqli_num_rows($email_check)=='0') {
            
            
        }
        else{
            
            $email_exists = "";
        }
//Match input Username with Databases' Username     
        $username_check = mysqli_query($con, "SELECT * FROM librarian WHERE username = '$username'");

        if (mysqli_num_rows($username_check)=='0') {
            
            
        }
        else{
            
            $username_exists = "";
        }

//Data insert to Database:
        $query = "INSERT INTO `student`(`fname`, `lname`, `email`, `username`, `password`, `phone`, `photo`) VALUES ('$fname', '$lname', '$email', '$username', '$password','$phone', '$photo_name')";
        $result = mysqli_query($con, $query);
        if ($result) {
            move_uploaded_file($_FILES['pp']['tmp_name'],'../image/librarian/'.$photo_name);
            $success = "";
            
        }
        else{
            $error = "";
        }
}
?>
<!DOCTYPE html>
<html lang="en" class="fixed accounts sign-in">
    <!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:06:17 GMT -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>LMS</title>
        <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
        <link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
        <!--BASIC css-->
        <!-- ========================================================= -->
        <link rel="stylesheet" href="../file/vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="../file/vendor/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="../file/vendor/animate.css/animate.css">
        <!--SECTION css-->
        <!-- ========================================================= -->
        <!--TEMPLATE css-->
        <!-- ========================================================= -->
        <link rel="stylesheet" href="../file/stylesheets/css/style.css">
    </head>
    <body>
        <div class="wrap">
            <!-- page BODY -->
            <!-- ========================================================= -->
            <div class="page-body animated slideInDown">
                
                <div class="logo text-center">
                    <h1>LMS</h1>
                    <!---------------------Registration Success Message---------------->
                    <?php
                    if (isset($success)) {
                    echo '<div class="alert alert-success text-center" role="alert">'."Registration Successful!".'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>';
                    
                    
                    } ?>
                    <!---------------------Registration Failed Message---------------->
                    <?php
                    if (isset($error)) {
                    echo '<div class="alert alert-warning text-center" role="alert">'."Sorry! Registration Failed. Please Try Again ".'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>';
                    
                    
                    } ?>
                    
                </div>
                <div class="box">
                    <!--SIGN IN FORM-->
                    <div class="panel mb-none">
                        <div class="panel-content bg-scale-0">
                            <form method="POST" action="<?=$_SERVER['PHP_SELF']?>"enctype="multipart/form-data">
                                <div class="form-group mt-md">
                                    <span class="input-with-icon">
                                        <input type="text" class="form-control" placeholder="First Name" name="fname" required="" value="<?php
                                        if(isset($fname))
                                        echo $fname;?>">
                                        <i class="fa fa-user"></i>
                                    </span>
                                </div>
                                <div class="form-group mt-md">
                                    <span class="input-with-icon">
                                        <input type="text" class="form-control" placeholder="Last Name" name="lname" required="" value="<?php
                                        if(isset($lname))
                                        echo $lname;?>">
                                        <i class="fa fa-user"></i>
                                    </span>
                                </div>
                                <div class="form-group mt-md">
                                    <!--------------Already Existed Email Error Message--------------->
                                        <?php
                                        if (isset($email_exists)) {
                                        
                                        echo '<span style="color:red;text-align:center;">This Email Alreday Exists</span>';
                                        
                                        }
                                        ?>
                                        
                                    <span class="input-with-icon">
                                        
                                        <input type="email" class="form-control" name="email" placeholder="Email" required="" value="<?php
                                        if(isset($email))
                                        echo $email;?>">
                                        <i class="fa fa-envelope"></i>
                                    </span>
                                </div>
                                <div class="form-group mt-md">
                                    <?php
                                        
                                        //...........Username more than 8 Character Error Message.........
                                        if (isset($username_l)) {
                                        
                                        echo '<span style="color:red;text-align:center;">'."Username more than 8 Character!".'</span>';
                                    }
                                    //Username Already Exists Message
                                    if (isset($username_exists)) {
                                        
                                        echo '<span style="color:red;text-align:center;">This Username Alreday Exists</span>';
                                        
                                        }
                                    ?>
                                   
                                        
                                    <span class="input-with-icon">
                                        
                                        
                                        
                                        <input type="text" class="form-control" placeholder="Username" name="username" required="" value="<?php
                                        if(isset($username))
                                        echo $username;?>">
                                        <i class="fa fa-sign-in"></i>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <?php
                                        
                                        //...........Password more than 8 Character Error Message.........
                                        if (isset($password_l)) {
                                        
                                        echo '<span style="color:red;text-align:center;">'."Password more than 8 Character!".'</span>';
                                        
                                        
                                        
                                        }
                                        ?>
                                    <span class="input-with-icon">
                                        
                                        <input type="password" class="form-control" name="password" placeholder="Password" required="" >
                                        <i class="fa fa-key"></i>
                                    </span>
                                </div>
                                
                                <div class="form-group mt-md">
                                    <span class="input-with-icon">
                                        <input type="text" class="form-control" placeholder="01*******" name="phone" pattern="01[1|3|5|6|7|8|9][0-9]{8}" required="" value="<?php
                                        if(isset($phone))
                                        echo $phone;?>">
                                        <i class="fa fa-phone"></i>
                                    </span>
                                </div>
                                <div class="form-group mt-md">
                                    <span class="input-with-icon">
                                        <input type="file" name="pp" required="" src ="" class="form-control">
                                        <i class="fa fa-user"></i>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <div class="checkbox-custom checkbox-primary">
                                        <input type="checkbox" id="terms" value="option1" required="">
                                        <label class="check" for="terms">I agree </label>  to the <a href="#">Terms and Conditions</a>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="register" value="Register" href="index.php" class="btn btn-primary btn-block">
                                </div>
                                <div class="form-group text-center">
                                    Have an account?, <a href="sign_in.php">Sign In</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
            </div>
        </div>
        <!--BASIC scripts-->
        <!-- ========================================================= -->
        <script src="../file/vendor/jquery/jquery-1.12.3.min.js"></script>
        <script src="../file/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="../file/vendor/nano-scroller/nano-scroller.js"></script>
        <!--TEMPLATE scripts-->
        <!-- ========================================================= -->
        <script src="../file/javascripts/template-script.min.js"></script>
        <script src="../file/javascripts/template-init.min.js"></script>
        
    </body>
    
</html>