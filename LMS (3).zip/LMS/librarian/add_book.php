<?php include 'header.php'; 
if (isset($_POST['save_book'])) {
$book_name = $_POST['book']; 
$book_img =
explode('.',$_FILES['book_img']['name']); 
$book_img = end($book_img);
$book_img = date('ymdhis').'.'.$book_img; 
$author_name =$_POST['author_name']; 
$publication_name = $_POST['publication_name'];
$purchase_date = $_POST['purchase_date']; 
$book_price = $_POST['book_price']; 
$book_quantity = $_POST['book_quantity'];
$available_quantity = $_POST['available_quantity'];
$librarian_username = $_SESSION['librarian_username']; 
$sql = "INSERT INTO `book`(`book_name`, `book_image`, `book_author_name`,
`book_publication_name`, `book_purchase_date`, `book_price`,
`book_quantity`, `available_quantity`, `librarian_username`) VALUES
('$book_name', '$book_img', '$author_name', '$publication_name',
'$purchase_date', '$book_price', '$book_quantity',
'$available_quantity', '$librarian_username')"; 
$result = mysqli_query($con,$sql); 
if ($result) {
move_uploaded_file($_FILES['book_img']['tmp_name'],
'../image/book/'.$book_img); 
$success = ""; } 
else
    { 
        $error = "";
         } 
     }
?> <!-- content HEADER --> <!--
========================================================= --> <div
    class="content-header"> <!-- leftside content header --> <div
    class="leftside-content-header"> <ul class="breadcrumbs"> <li><i
        class="fa fa-home" aria-hidden="true"></i><a
        href="index.php">Dashboard</a></li> <li><a href="add_book.php">Add
    Book</a></li> </ul>
    
</div> </div> <!--
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
--> <div class="row animated fadeInUp"> <div class="col-sm-6 col-sm-offset-3">
    <div class="panel"> <div class="panel-content"> <div class="row"> <div
        class="col-md-12"> <?php if (isset($success)) { echo '<div class="alert
            alert-success text-center" role="alert">'."Book Inserted
            Successfully!".'<button type="button" class="close" data-dismiss="alert"
            aria-label="Close"> <span aria-hidden="true">&times;</span> </button></div>';
            
            
            } ?>
            <!---------------------Registration Failed Message---------------->
            <?php
            if (isset($error)) {
            echo '<div class="alert alert-warning text-center" role="alert">'."Sorry! Book Insert Failed. Please Try Again ".'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button></div>';
            
            
            } ?>
            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                <h3 class="mb-lg"><center><li class="fa fa-book"></li> Book</center></h3>
<div class="form-group">
    <label for="book" class="col-sm-4 control-label">Book Name</label>
    <div class="col-sm-8">
        <input type="text" class="form-control" id="book" placeholder="Book Name" name="book" required="">
    </div>
</div>
<div class="form-group">
    <label for="book_img" class="col-sm-4 control-label">Book Image</label>
    <div class="col-sm-8">
        <input type="file" class="" id="book_img" placeholder="" name="book_img" required="">
    </div>
</div>
<div class="form-group">
    <label for="author_name" class="col-sm-4 control-label">Author Name</label>
    <div class="col-sm-8">
        <input type="text" class="form-control" id="author_name" placeholder="Book Author Name" name="author_name" required="">
    </div>
</div>
<div class="form-group">
    <label for="publication_name" class="col-sm-4 control-label">Publication Name</label>
    <div class="col-sm-8">
        <input type="text" class="form-control" id="author_name" placeholder="Publication Name" name="publication_name" required="">
    </div>
</div>
<div class="form-group">
    <label for="purchase_date" class="col-sm-4 control-label">Purchase Date</label>
    <div class="col-sm-8">
        <input type="date" class="form-control" id="purchase_date" placeholder="Purchase Date" name="purchase_date" required="">
    </div>
</div>
<div class="form-group">
    <label for="book_price" class="col-sm-4 control-label">Book Price</label>
    <div class="col-sm-8">
        <input type="number" class="form-control" id="book_price" placeholder="Book Price" name="book_price" required="">
    </div>
</div>
<div class="form-group">
    <label for="book_quantity" class="col-sm-4 control-label">Book Quantity</label>
    <div class="col-sm-8">
        <input type="number" class="form-control" id="book_quantity" placeholder="Book Quantity" name="book_quantity" required="">
    </div>
</div>
<div class="form-group">
    <label for="available_quantity" class="col-sm-4 control-label">Available Quantity</label>
    <div class="col-sm-8">
        <input type="number" class="form-control" id="available_quantity" placeholder="Available Quantity" name="available_quantity" required="">
    </div>
</div>
                
                
                <div class="form-group">
                    <div class="col-sm-offset-4 col-sm-8">
                        <button type="submit" class="btn btn-primary" name="save_book"><li class="fa fa-save"></li> Save Book</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
<?php include 'footer.php';?>