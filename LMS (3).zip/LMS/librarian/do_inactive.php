<?php
include '../dbcon.php';
$id = base64_decode($_GET['id']);
$update = mysqli_query($con, "UPDATE student SET status='0' WHERE id='$id'");
if ($update) {
	header('Location:student.php');
}
?>