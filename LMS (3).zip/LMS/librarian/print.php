<?php include'../dbcon.php';
$result = mysqli_query($con, "SELECT * FROM `student` ");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>Print All Student</title>
        
        <!--load progress bar-->
        <script src="../file/vendor/pace/pace.min.js"></script>
        <link href="../file/vendor/pace/pace-theme-minimal.css" rel="stylesheet" />
        <!--BASIC css-->
        <!-- ========================================================= -->
        <link rel="stylesheet" href="../file/vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="../file/vendor/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="../file/vendor/animate.css/animate.css">
        <!--SECTION css-->
        <!-- ========================================================= -->
        <!--Notification msj-->
        <link rel="stylesheet" href="../file/vendor/toastr/toastr.min.css">
        <!--Magnific popup-->
        <link rel="stylesheet" href="../file/vendor/magnific-popup/magnific-popup.css">
        <link rel="stylesheet" href="../file/vendor/data-table/media/css/dataTables.bootstrap.min.css">
        <!--TEMPLATE css-->
        <!-- ========================================================= -->
        </head>
        <body onload="window.print()">
        	<?php $sl=1;
        		$page = 1;
        		$total = mysqli_num_rows($result);
        		
        		$par_page = 22;
        		while ($row = mysqli_fetch_assoc($result)) {
        			if ($sl % $par_page == 1) {
        				echo page_header();
        			}
        			?>

        			<tr>
        				<td><?php echo $sl;?></td>
        				<td><?php echo $row['fname'].' '.$row['lname'];?></td>
        				<td><?php echo $row['roll'];?></td>
        				<td><?php echo $row['email'];?></td>
        				<td><?php echo $row['phone'];?></td>
        			</tr>
        			<?php 
        			if ($sl % $par_page == 0 || $total == $par_page) {
        				echo page_footer($page++);
        			}
        		$sl++; }
        	?>
        
        		</tbody>
        	
        
        <!-- <div style="page-break-after: avoid;"></div>
        <div style="page-break-after: inherit;"></div> -->


<script src="../file/vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="../file/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../file/vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="../file/javascripts/template-script.min.js"></script>
<script src="../file/javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<!-- ========================================================= -->
<!--Notification msj-->
<script src="../file/vendor/toastr/toastr.min.js"></script>
<!--morris chart-->
<script src="../file/vendor/chart-js/chart.min.js"></script>
<!--Gallery with Magnific popup-->
<script src="../file/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="../file/vendor/data-table/media/js/jquery.dataTables.min.js"></script>
<script src="../file/vendor/data-table/media/js/dataTables.bootstrap.min.js"></script>
<!--Examples-->
<script src="../file/javascripts/examples/tables/data-tables.js"></script>
<!--Examples-->
<script src="../file/javascripts/examples/dashboard.js"></script>
</body>
</html>
<?php function page_header(){
	$data='<div align="center" style="page-break-after: ; height: 1050px; width:755px; box-sizing: border-box; margin: auto;">
        	<h1>Complete Outlet,Dhaka</h1>
        	<h3>কম্পলিট আউটলেট,ঢাকা</h3>
        	<table class="table table-bordered">
        		<thead>
        			<th>SI</th>
        			<th>Name</th>
        			<th>Roll</th>
        			<th>Email</th>
        			<th>Phone</th>
        		</thead>
        		<tbody>';


return $data;
}

function page_footer($page){
	$data = '
	</table>
      <p>Page:-'.$page.'</p>  	
        </div>';
	return $data;
}

?>