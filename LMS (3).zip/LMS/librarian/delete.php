<?php 
include '../dbcon.php';
if (isset($_GET['bookdelete'])) {
	$id = base64_decode($_GET['bookdelete']);
mysqli_query($con, "DELETE FROM `book` WHERE id = '$id'");
header('Location:manage_book.php');

}


?>