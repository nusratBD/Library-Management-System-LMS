<?php 
include 'header.php';
?>
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><i aria-hidden="true"></i><a href="librarian.php">All Librarians</a></li>
        </ul>
        
    </div>

</div>
<div class="row animated fadeInUp">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b><li class="fa fa-users"></li> All Librarians</b></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Profile Pic</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM `librarian`";
                            $result = mysqli_query($con,$sql);
                            
                            while($row = mysqli_fetch_assoc($result)){?>
                            <tr>
                            	<td><?php echo $row['id']?></td>
                                <td><?php echo ucwords($row['fname'].' '.$row['lname']);?></td>
                                
                                
                                <td><?php echo $row['email']?></td>
                                <td><?php echo $row['username']?></td>
                                
                                <td><img src="../image/librarian/<?php echo $row['pp'];?>" style="height: 50px; width:55px;"></td>
                                
                                
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php 
include 'footer.php';
?>