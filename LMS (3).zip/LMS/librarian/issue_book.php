<?php include 'header.php';
if (isset($_POST['issue_book'])) {
    $student_id = $_POST['student_id'];
    $book_id = $_POST['book_id'];
    $issue_date = $_POST['issue_date'];
    $result = mysqli_query($con, "INSERT INTO `issue_book`(`student_id`, `book_id`, `issue_date`) VALUES ('$student_id', '$book_id', '$issue_date')");
    if ($result) { ?>
        <script type="text/javascript">
            alert('Book Issued Successfully!');
        </script>
    <?php 
    $update1 = mysqli_query($con,"SELECT * FROM `book` WHERE `id`= '$book_id'");
    $update2 = mysqli_fetch_assoc($update1);
    $available_quantity = $update2['available_quantity']-'1';
    mysqli_query($con,"UPDATE `book` SET `available_quantity`='$available_quantity' WHERE `id`= '$book_id'");    
    }else{
        ?>
      <script type="text/javascript">
            alert('Book Not Issued.Try Again!');
        </script> 
    <?php  
    }
}
?>
                        <!-- content HEADER -->
                        <!-- ========================================================= -->
                        <div class="content-header">
                            <!-- leftside content header -->
                            <div class="leftside-content-header">
                                <ul class="breadcrumbs">
                                    <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                                    <li><a href="issue_book.php">Issue Book</a></li>
                                    
                                </ul>
                                
                            </div>
                        </div>
                        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                        <div class="row animated fadeInUp">
                           <div class="col-sm-6 col-sm-offset-3">
                               <div class="panel">
                        <div class="panel-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <form class="form-inline" method="POST" action="">
                                        
                                        <div class="form-group">
                                            
                                            <select class="form-control" name="student_id">
                                                <option>Select</option>
                                                <?php
                                                    $sql = "SELECT * FROM `student`WHERE status = '1' ORDER BY roll ASC ";
                                                    $result = mysqli_query($con,$sql);
                            
                                                    while($row = mysqli_fetch_assoc($result)){?>
                                                    <option value="<?=$row['id']?>"><?php echo ucwords($row['fname'].' '.$row['lname'].' - ( '.$row['roll'].' )')?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary" name="search">Send</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <?php if(isset($_POST['search'])){
                            $id = $_POST['student_id'];
                            $sql = "SELECT * FROM `student` WHERE id = '$id'";
                            $result = mysqli_query($con,$sql);
                            
                            $row = mysqli_fetch_assoc($result);
                            
                            ?>
                            <div class="panel">
                        <div class="panel-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="POST" action="">
                                        
                                        <div class="form-group">
                                            <label for="name">Student Name</label>
                                            <input type="hidden" name="student_id" value="<?=$row['id']; ?>">
                                            <input type="text" class="form-control" id="name" value="<?=ucwords($row['fname'].' '.$row['lname'])?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="select_book">Select Book</label>
                                            <select class="form-control" name="book_id" id="select_book">
                                                <option>Select</option>
                                                <?php
                                                    $sql = "SELECT * FROM `book` WHERE `available_quantity`>0";
                                                    $result = mysqli_query($con,$sql);
                            
                                                    while($row = mysqli_fetch_assoc($result)){?>
                                                    <option value="<?=$row['id']?>"><?php echo ucwords($row['book_name'])?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="issue_date">Book Issue Date</label>
                                            <input type="text" id="issue_date" name="issue_date" value="<?=date('d-M-Y'); ?>" class="form-control" readonly>
                                            
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary" name="issue_book"><i class="fa fa-arrow-circle-left"></i> Issue Book</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                            <?php  
                            }
                            ?>
                        </div>
                    </div>
                           </div> 
                           
                        </div>
                    </div>
                   
                   <?php include 'footer.php';?>
                   