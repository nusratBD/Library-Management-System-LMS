<?php include 'header.php';


?>
                        <!-- content HEADER -->
                        <!-- ========================================================= -->
                        <div class="content-header">
                            <!-- leftside content header -->
                            <div class="leftside-content-header">
                                <ul class="breadcrumbs">
                                    <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                                    
                                </ul>
                                
                            </div>
                        </div>
                        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                        
                        <div class="row animated fadeInUp">
                           <div class="col-sm-12">
                               <div class="row">
                    
                   <?php 
                        $student = mysqli_query($con, "SELECT * FROM `student`");
                        $total_student = mysqli_num_rows($student);
                        ?>
                    <!--BOX Style 1-->
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="student.php">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-users"></i> <?php echo $total_student;?> </h1>
                                    <h4 class="subtitle color-darker-1">Total Students</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php 
                        $librarian = mysqli_query($con, "SELECT * FROM `librarian`");
                        $total_librarian = mysqli_num_rows($librarian);
                        ?>  
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="librarian.php">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-users"></i> <?php echo $total_librarian;?> </h1>
                                    <h4 class="subtitle color-darker-1">Total Librarians</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php 
                        $book = mysqli_query($con, "SELECT * FROM `book`");
                        $total_book = mysqli_num_rows($book);
                        $total_amount = mysqli_query($con, "SELECT SUM(`book_quantity`) as total FROM `book`");
                        $book_amount = mysqli_fetch_assoc($total_amount);
                        $available_amount = mysqli_query($con, "SELECT SUM(`available_quantity`) as total FROM `book`");
                        $available_book = mysqli_fetch_assoc($available_amount);
                        ?> 
                        <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="panel widgetbox wbox-1 bg-lighter-2 color-light">
                            <a href="manage_book.php">
                                <div class="panel-content">
                                    <h1 class="title color-darker-2"> <i class="fa fa-book"></i> <?php echo $total_book.' ( '.$book_amount['total'].' - '.$available_book['total'].' ) ';?> </h1>
                                    <h4 class="subtitle color-darker-1">Total Books</h4>
                                </div>
                            </a>
                        </div>
                    </div>   
                </div>
                           </div> 
                           
                        </div>
                    </div>
                   
                   <?php include 'footer.php';?>
                   