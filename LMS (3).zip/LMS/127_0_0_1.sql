-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 07:05 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbook`
--
CREATE DATABASE IF NOT EXISTS `bloodbook` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bloodbook`;

-- --------------------------------------------------------

--
-- Table structure for table `donorregistration`
--

CREATE TABLE `donorregistration` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `phone` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `district` text NOT NULL,
  `thana` text NOT NULL,
  `birthDay` varchar(2) NOT NULL,
  `birthMonth` text NOT NULL,
  `birthYear` varchar(4) NOT NULL,
  `bloodGroup` varchar(5) NOT NULL,
  `lastDonation` varchar(4) NOT NULL,
  `lastDMonth` text NOT NULL,
  `lastDDate` varchar(2) NOT NULL,
  `gender` text NOT NULL,
  `wish` text NOT NULL,
  `profilePic` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donorregistration`
--

INSERT INTO `donorregistration` (`id`, `name`, `phone`, `password`, `district`, `thana`, `birthDay`, `birthMonth`, `birthYear`, `bloodGroup`, `lastDonation`, `lastDMonth`, `lastDDate`, `gender`, `wish`, `profilePic`) VALUES
(41, 'Soyud Shifat Ahmed', '017000001', 'ZXQjGd4q6NHb6eu', 'Rajshahi', 'Rajshahi', '12', 'Nov', '1999', 'O+', '2019', 'Aug', '18', 'Male', 'Yes', 'Array'),
(42, 'Naem Islam', '015000003', 'ZXQjGd4q6NHb6eu', 'Rajshahi', 'Rajshahi', '10', 'Sep', '1996', 'O+', '2006', 'Mar', '10', 'Male', 'Yes', 'Array'),
(44, 'Golam Mohiuddin', '017000002', '12345', 'Pabna', 'Pabna', '14', 'Aug', '1988', 'B+', '2004', 'Sep', '16', 'Male', 'Yes', 'Array'),
(45, 'Alamgir Kobir Sun', '0131000002', 'ZXQjGd4q6NHb6eu', 'Bogura', 'Bogura', '13', 'Jul', '1993', 'A+', '2009', 'May', '12', 'Male', 'Yes', 'Array'),
(65, 'Nusrat Hurain ', '01708778173', 'ZXQjGd4q6NHb6eu', 'Lakshmipur', 'Lakshmipur', '17', 'Oct', '1996', 'A+', '2018', 'Mar', '7', 'Female', 'Yes', 'profilePic/23_02_20_10_01_25pm2.jpg'),
(68, 'nusrat.hurain15@gmail.com', '', 'ZXQjGd4q6NHb6eu', '', '', 'Da', 'Month', 'Year', 'A+', 'Year', 'Month', 'Da', '', '', 'profilePic/23_02_20_11_45_09pm'),
(69, 'nusrat.hurain15@gmail.com', '', 'ZXQjGd4q6NHb6eu', '', '', 'Da', 'Month', 'Year', 'A+', 'Year', 'Month', 'Da', '', '', 'profilePic/24_02_20_10_13_29pm'),
(70, 'Nusrat Hurain ', '01734753809', '01734753809', 'Dhaka', 'Lakshmipur', '16', 'Oct', '1996', 'A+', '2017', 'Apr', '4', 'Female', 'Yes', 'profilePic/21_04_20_03_17_37pm55.jpg'),
(71, 'Kawsar Ahmed', '01554126726', '01554126726', 'Dhaka', 'Dhaka', '12', 'Jun', '1991', 'B+', '2008', 'Jun', '16', 'Male', 'Yes', 'profilePic/24_02_20_10_58_50pmMarketing.jpg'),
(72, 'Haspa Boruya', '123456', '123456', 'Nowakhali', 'Nowakhali', '17', 'Oct', '1986', 'A+', '2004', 'Oct', '17', 'Male', 'Yes', 'profilePic/24_02_20_11_26_21pm8.png'),
(74, 'Ariful Haque', '01222222222', '123456', 'Dhaka', 'Dhaka', '16', 'Oct', '1985', 'A+', '2005', 'Jul', '17', 'Male', 'Yes', 'profilePic/17_03_20_04_22_54pmbPic1.jpg'),
(75, 'Ahmed Sharif', '013333333', '123456', 'Dhaka', 'Gazipur', '15', 'Aug', '1986', 'O+', '2004', 'Oct', '16', 'Male', 'Yes', 'profilePic/18_03_20_11_20_43am7.jpg'),
(76, 'Mahmuda Khatun', '01234566677', '123456', 'ChapiNowabGonj', 'ChapaiNowabGonj', '15', 'Aug', '1997', 'A+', '2019', 'Jan', '1', 'Female', 'Yes', 'profilePic/18_03_20_11_32_25am9.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donorregistration`
--
ALTER TABLE `donorregistration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donorregistration`
--
ALTER TABLE `donorregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- Database: `college`
--
CREATE DATABASE IF NOT EXISTS `college` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `college`;

-- --------------------------------------------------------

--
-- Table structure for table `dhaka_tour`
--

CREATE TABLE `dhaka_tour` (
  `Roll` int(5) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dhaka_tour`
--

INSERT INTO `dhaka_tour` (`Roll`, `Name`, `Gender`, `Age`) VALUES
(101, 'Atik', 'Male', 18),
(102, 'Sahana', 'Female', 17),
(103, 'Jami', 'Male', 18),
(104, 'Meherab', 'Male', 18),
(105, 'Sujana', 'Female', 17),
(106, 'Aftab', 'Male', 18);

-- --------------------------------------------------------

--
-- Table structure for table `ssc_result`
--

CREATE TABLE `ssc_result` (
  `Reg_Number` int(10) NOT NULL,
  `Roll` int(6) NOT NULL,
  `GPA` double(3,2) NOT NULL,
  `Group` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ssc_result`
--

INSERT INTO `ssc_result` (`Reg_Number`, `Roll`, `GPA`, `Group`) VALUES
(20201, 102, 3.50, 'Arts'),
(20202, 101, 4.00, 'Science'),
(20203, 105, 4.25, 'Commerce'),
(20204, 103, 4.50, 'Science'),
(20205, 107, 3.25, 'Arts'),
(20206, 104, 3.75, 'Commerce'),
(20207, 108, 4.00, 'Science'),
(20208, 109, 4.75, 'Science'),
(20209, 110, 5.00, 'Commerce'),
(20210, 110, 4.00, 'Arts'),
(20211, 111, 5.00, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `ssc_students`
--

CREATE TABLE `ssc_students` (
  `Roll` int(6) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ssc_students`
--

INSERT INTO `ssc_students` (`Roll`, `Name`, `Gender`, `Age`) VALUES
(101, 'Fahim', 'Male', 18),
(102, 'Isita', 'Female', 17),
(103, 'Rahul', 'Male', 19),
(104, 'Forhad', 'Male', 18),
(105, 'Mim', 'Female', 18),
(106, 'Sahana', 'Female', 17),
(107, 'Ariyan', 'Male', 18),
(112, 'Siam', 'Male', 19),
(113, 'Hashi', 'Female', 17),
(114, 'Jara', 'Female', 18),
(115, 'Ifti', 'Male', 18),
(116, 'Jabir', 'Male', 19);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Roll` int(5) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(3) NOT NULL,
  `GPA` double(3,2) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Date_Of_Birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Roll`, `Name`, `Gender`, `Age`, `GPA`, `City`, `Date_Of_Birth`) VALUES
(101, 'Rahim', 'Male', 18, 3.50, 'Dhaka', '1996-09-27'),
(102, 'Tahira', 'Female', 17, 4.00, 'Sylhet', '1996-06-13'),
(103, 'Nazmul', 'Male', 18, 3.75, 'Khulna', '1996-05-21'),
(104, 'Aysha', 'Female', 18, 3.00, 'Rajshahi', '1996-02-12'),
(105, 'Afsana', 'Female', 17, 4.50, 'Sylhet', '1996-01-27'),
(106, 'Rafi', 'Male', 18, 4.25, 'Dhaka', '1996-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `sylhet_tour`
--

CREATE TABLE `sylhet_tour` (
  `Roll` int(5) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sylhet_tour`
--

INSERT INTO `sylhet_tour` (`Roll`, `Name`, `Gender`, `Age`) VALUES
(101, 'Atik', 'Male', 18),
(105, 'Sujana', 'Female', 17),
(108, 'Nafisa', 'Female', 17),
(109, 'Himel', 'Male', 18),
(113, 'Kabbo', 'Male', 18),
(117, 'Omi', 'Male', 18);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) UNSIGNED NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Department` varchar(10) NOT NULL,
  `Salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dhaka_tour`
--
ALTER TABLE `dhaka_tour`
  ADD PRIMARY KEY (`Roll`);

--
-- Indexes for table `ssc_result`
--
ALTER TABLE `ssc_result`
  ADD PRIMARY KEY (`Reg_Number`);

--
-- Indexes for table `ssc_students`
--
ALTER TABLE `ssc_students`
  ADD PRIMARY KEY (`Roll`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Roll`);

--
-- Indexes for table `sylhet_tour`
--
ALTER TABLE `sylhet_tour`
  ADD PRIMARY KEY (`Roll`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dhaka_tour`
--
ALTER TABLE `dhaka_tour`
  MODIFY `Roll` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `ssc_result`
--
ALTER TABLE `ssc_result`
  MODIFY `Reg_Number` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20212;

--
-- AUTO_INCREMENT for table `ssc_students`
--
ALTER TABLE `ssc_students`
  MODIFY `Roll` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `Roll` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `sylhet_tour`
--
ALTER TABLE `sylhet_tour`
  MODIFY `Roll` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `eece_pust`
--
CREATE DATABASE IF NOT EXISTS `eece_pust` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eece_pust`;

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `student_id` int(5) NOT NULL,
  `name` varchar(50) NOT NULL,
  `roll` int(6) NOT NULL,
  `semester` varchar(3) NOT NULL,
  `city` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `entry_time` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_id`, `name`, `roll`, `semester`, `city`, `phone`, `photo`, `entry_time`) VALUES
(3, 'Golam Mohiuddin Tusher', 170504, '3-1', 'Pabna', '01795232194', '170504.jpg', '2020-04-24 09:52:06.825393'),
(4, 'Alamgir Kobir Sun', 170505, '3-1', 'Bogura', '01788402055', '170505.jpg', '2020-04-21 09:13:43.900520'),
(5, 'Md Aheteshamul Haque', 170506, '3-1', 'Dinajpur', '01774471534', '170506.jpg', '2020-04-19 17:36:49.568648');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `Status` varchar(10) NOT NULL,
  `logindate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `username`, `password`, `photo`, `Status`, `logindate`) VALUES
(1, 'Nusrat Hurain', 'nusrat.hurain15@gmail.com', 'Nusrat20170515', '346cd65cab861bc916bcf7311e607b70', 'Nusrat20170515.jpg', 'active', '2020-04-21 16:58:20'),
(2, 'Anika Tasnim Akhi', 'anika@gmail.com', 'Anika20170533', '5cd4739d0cc743fbdeb320b594836e16', 'Anika20170533.jpg', 'active', '2020-04-21 16:58:20'),
(3, 'Simla Islam', 'simla@gmail.com', 'Simla20170521', '65e1fb7c036761cacfd38cbfb948d42a', 'Simla20170521.jpg', '', '2020-04-21 16:58:20'),
(4, 'Sabrina Manowar', 'sabrina@gmail.com', 'Sabrina20170534', 'aae310c3a9ac551e1bf6374ce69d3db8', 'Sabrina20170534.jpg', '', '2020-04-22 15:52:37'),
(6, 'Mahmuda Khatun', 'mahmuda@gmail.com', 'Mahmuda20170912', '6d45af488178a39fe1ec6042a909830f', 'Mahmuda20170912.jpg', '', '2020-04-22 15:55:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `UNIQUE` (`roll`),
  ADD UNIQUE KEY `roll` (`roll`,`phone`),
  ADD KEY `semester` (`semester`),
  ADD KEY `roll_2` (`roll`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `student_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- Database: `lms`
--
CREATE DATABASE IF NOT EXISTS `lms` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lms`;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(6) NOT NULL,
  `book_name` varchar(100) NOT NULL,
  `book_image` varchar(100) NOT NULL,
  `book_author_name` varchar(50) NOT NULL,
  `book_publication_name` varchar(50) NOT NULL,
  `book_purchase_date` date NOT NULL,
  `book_price` int(11) NOT NULL,
  `book_quantity` int(11) NOT NULL,
  `available_quantity` int(11) NOT NULL,
  `librarian_username` varchar(50) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `book_name`, `book_image`, `book_author_name`, `book_publication_name`, `book_purchase_date`, `book_price`, `book_quantity`, `available_quantity`, `librarian_username`, `date_time`) VALUES
(12, 'বিজ্ঞানীর কবলে বিজ্ঞানী test', '200526082256.jpg', 'এনায়েত রসূল', 'বইঘর', '2020-05-18', 40, 100, 5, 'Nusrat20170515', '2020-06-03 08:05:08'),
(13, 'মোরা বড় হতে চাই A-Z', '200527123407.png', 'আহসান হাবীব ইমরোজ', 'ICSS', '2020-05-11', 40, 100, 31, 'Nusrat20170515', '2020-06-06 18:47:34'),
(15, 'Youth Problem', '200606063654.jpg', 'Ahmad Mabrur', 'বিন্দু প্রকাশ', '2020-06-02', 100, 40, 39, 'Nusrat20170515', '2020-06-06 18:46:16'),
(16, 'বদর যুদ্ধ', '200606063803.jpg', 'মোঃ শেখ', 'ICSS', '2020-06-03', 80, 30, 19, 'Nusrat20170515', '2020-06-06 18:47:03');

-- --------------------------------------------------------

--
-- Table structure for table `demo`
--

CREATE TABLE `demo` (
  `id` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Roll` int(6) NOT NULL,
  `Semester` varchar(5) NOT NULL,
  `Mobile` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `demo`
--

INSERT INTO `demo` (`id`, `Name`, `Roll`, `Semester`, `Mobile`) VALUES
(1, 'Sifat', 20170501, '3-1', '01708778173'),
(2, 'Naem', 20170502, '3-1', '01708778173'),
(3, 'Mujahid', 20170503, '2-1', '01708778173'),
(4, 'Tushar', 20170504, '3-1', '01708778173'),
(5, 'Sun', 20170505, '3-1', '01708778173'),
(6, 'Ahetesham', 20170506, '3-1', '01708778173'),
(7, 'Raton', 20170510, '3-1', '01708778173'),
(8, 'Mahmuda', 20170512, '3-1', '01708778173'),
(9, 'Almagir', 20170513, '2-1', '01708778173'),
(10, 'Towfik', 20170514, '3-1', '01708778173'),
(11, 'Nusrat', 20170515, '2-2', '01708778173'),
(12, 'Trishna', 20170516, '3-1', '01708778173'),
(13, 'Anis', 20170517, '3-1', '01708778173'),
(14, 'Sagor', 20170518, '3-1', '01708778173'),
(15, 'Simla', 20170519, '3-1', '01708778173'),
(16, 'Simanto', 20170520, '3-1', '01708778173'),
(17, 'Rahat', 20170521, '3-1', '01708778173'),
(18, 'Tonmoy', 20170523, '3-1', '01708778173'),
(19, 'Boni', 20170525, '3-1', '01708778173'),
(20, 'Parvez', 20170526, '3-1', '01708778173'),
(21, 'Riad', 20170528, '3-1', '01708778173'),
(22, 'Anik', 20170529, '3-1', '01708778173'),
(23, 'Istiak', 20170530, '3-1', '01708778173'),
(24, 'Afridi', 20170531, '3-1', '01708778173'),
(25, 'Anika', 20170531, '3-1', '01708778173'),
(26, 'Sabrina', 20170534, '3-1', '01708778173'),
(27, 'Sabbir', 20170535, '3-1', '01708778173'),
(28, 'Aysha', 20170536, '3-1', '01708778173'),
(29, 'Didar', 20170537, '3-1', '01708778173'),
(30, 'Mahmudul', 20170538, '3-1', '01708778173');

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `issue_date` varchar(10) NOT NULL,
  `return_date` varchar(10) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`id`, `student_id`, `book_id`, `issue_date`, `return_date`, `date_time`) VALUES
(1, 16, 12, '0000-00-00', '', '2020-06-05 10:12:01'),
(2, 17, 13, '0000-00-00', '', '2020-06-05 10:12:05'),
(3, 16, 13, '31-05-2020', '06-06-20', '2020-06-06 18:47:34'),
(4, 16, 13, '04-06-2020', '05-06-20', '2020-06-05 10:16:03'),
(5, 17, 13, '04-06-2020', '05-06-20', '2020-06-05 10:16:34'),
(6, 16, 15, '06-Jun-202', '06-06-20', '2020-06-06 18:46:16'),
(7, 17, 15, '06-Jun-202', '06-06-20', '2020-06-06 18:45:17'),
(8, 16, 16, '06-Jun-202', '', '2020-06-06 18:47:03');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `id` int(6) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `pp` varchar(100) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`id`, `fname`, `lname`, `email`, `username`, `phone`, `password`, `pp`, `date_time`) VALUES
(100001, 'Nusrat', 'Hurain', 'nusrat.hurain15@gmail.com', 'Nusrat20170515', '', '346cd65cab861bc916bcf7311e607b70', '', '2020-05-10 10:08:44'),
(100004, 'Anika', 'Tasnim', 'tasnim@gmail.com', 'Anika20170533', '01708778172', 'c633d41c73ce1d7d1ce124bd4ede5516', 'Anika20170533.', '2020-06-07 12:58:23'),
(100006, 'Simla', 'Islam', 'simla@gmail.com', 'Simla20170521', '01708778174', 'c7fc2b39cb4fbe16b90976d64c239b1b', 'Simla20170521.', '2020-06-07 13:02:32'),
(100012, 'Sabrina', 'Manowar', 'sabrina@gmail.com', 'sabrina20170534', '01708778175', 'f41fd970affacbc0ddc6426e1e7df959', 'sabrina20170534.', '2020-06-07 13:09:45'),
(100014, 'Aysha', 'Siddika', 'aysha@gmail.com', 'Aysha20170536', '01708778176', 'be8861eb6ba256fa0bfcce954dbeae90', '', '2020-06-07 13:13:44'),
(100015, 'Aronno', 'Ahmed', 'aronno@gmail.com', 'Aronno1234', '01708778177', '3857be67b34a81ab098429ad7dfa4a2e', '', '2020-06-07 13:15:36'),
(100022, 'Aheteshamul', 'Haque', 'ahetesham@gmail.com', 'Ahetesham20170506', '01708778178', 'c69a55d1bd85ad396c7656ef2cca71e2', 'Ahetesham20170506.jpg', '2020-06-07 14:19:43'),
(100024, 'Naem', 'Islam', 'naem@gmail.com', 'Naem20170502', '01708778179', '16bd89cafbff4625b91a427e9c30263b', 'Naem20170502.jpg', '2020-06-07 14:21:28'),
(100025, 'Mujahid', 'Hossen', 'mujahid@gmail.com', 'Mujahid20170503', '01708778181', 'f3d61ceea7f106c4608d865db8bd3e5d', 'Mujahid20170503.jpg', '2020-06-07 13:31:01');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(6) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `roll` int(6) NOT NULL,
  `reg` int(6) NOT NULL,
  `phone` text NOT NULL,
  `photo` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fname`, `lname`, `email`, `username`, `password`, `roll`, `reg`, `phone`, `photo`, `status`, `date`) VALUES
(1, 'Nusrat', 'Hurain', 'nusrat@gmail.com', 'Nusrat20170515', '346cd65cab861bc916bcf7311e607b70', 170515, 201715, '01708778178', 'Nusrat20170515.png', 1, '2020-06-07 16:47:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `demo`
--
ALTER TABLE `demo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `roll` (`roll`),
  ADD UNIQUE KEY `reg` (`reg`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `demo`
--
ALTER TABLE `demo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `librarian`
--
ALTER TABLE `librarian`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100026;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Database: `online_shop`
--
CREATE DATABASE IF NOT EXISTS `online_shop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `online_shop`;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `short description` text NOT NULL,
  `publication_status` tinyint(4) NOT NULL,
  `factory_location` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `short description`, `publication_status`, `factory_location`) VALUES
(1, 'Cloth', 'Pure Cotton', 0, ''),
(2, 'Food', 'Good Food', 1, 'Bonani'),
(3, 'Fruits', 'Fresh Fruit', 1, ''),
(4, 'Electronics', 'Good Product', 0, ''),
(6, 'Bags', 'Pure Lather', 0, ''),
(101, 'Nusrat', 'Very Lonely', 0, ''),
(102, 'Mita', 'Crazy', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(300) NOT NULL,
  `profile_pic` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `oder_product`
--

CREATE TABLE `oder_product` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `price` float NOT NULL,
  `quantity` int(11) NOT NULL,
  `long description` text NOT NULL,
  `short description` text NOT NULL,
  `thumbnail pic` varchar(200) NOT NULL,
  `large pic` varchar(200) NOT NULL,
  `date_time` datetime NOT NULL,
  `publication_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oder_product`
--
ALTER TABLE `oder_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oder_product`
--
ALTER TABLE `oder_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin DEFAULT NULL,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

--
-- Dumping data for table `pma__navigationhiding`
--

INSERT INTO `pma__navigationhiding` (`username`, `item_name`, `item_type`, `db_name`, `table_name`) VALUES
('root', 'product', 'table', 'online_shop', '');

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"bloodbook\",\"table\":\"donorregistration\"},{\"db\":\"bloodbook\",\"table\":\"donorRegistration\"},{\"db\":\"school_management_software\",\"table\":\"students\"},{\"db\":\"college\",\"table\":\"student\"},{\"db\":\"college\",\"table\":\"student_view\"},{\"db\":\"college\",\"table\":\"dhaka_tour\"},{\"db\":\"college\",\"table\":\"sylhet_tour\"},{\"db\":\"college\",\"table\":\"ssc_result\"},{\"db\":\"college\",\"table\":\"ssc_students\"},{\"db\":\"college\",\"table\":\"teacher\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'bloodbook', 'donorregistration', '{\"sorted_col\":\"`donorregistration`.`id` ASC\"}', '2020-02-15 17:53:00'),
('root', 'online_shop', 'category', '{\"sorted_col\":\"`category`.`factory_location`  DESC\"}', '2020-01-10 20:19:50'),
('root', 'online_shop', 'product', '{\"CREATE_TIME\":\"2019-12-21 17:25:08\",\"col_order\":[0,1,2,3,4,5,6,7,8,9],\"col_visib\":[1,1,1,1,1,1,1,1,1,1]}', '2019-12-22 14:13:34');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin DEFAULT NULL,
  `data_sql` longtext COLLATE utf8_bin DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2020-02-20 09:13:08', '{\"Console\\/Mode\":\"collapse\",\"NavigationWidth\":315}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `school_management_software`
--
CREATE DATABASE IF NOT EXISTS `school_management_software` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `school_management_software`;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `phone`, `address`) VALUES
(1, 'Tithi Moni', '0170..........7', 'Lakshmipur'),
(2, 'Anika', '0170..........7', 'Mymensingh'),
(4, 'Sabrina', '0170..........7', 'Kustia'),
(5, 'Mahmuda', '0170..........7', 'ChapaiNowabGonj'),
(6, 'Trishna', '0170..........7', 'Rangpur'),
(8, 'Riya', '0170..........7', 'Sirajgonj'),
(10, 'Sifat', '017............', 'Rajshahi'),
(11, 'Sifat Ahmed', '017..........3', 'Rajshahi'),
(12, 'Naem Islam', '017............', 'Rajshahi'),
(13, 'Md Mujahid', '0171...........', 'Pabna'),
(14, 'Tushar Khan', '017.........1', 'Pabna'),
(17, 'Nusrat Hurain', '01708778173', 'Santir Nir Girls Hostel, Kaliko Cotton Mill, Rajapur,Pabna');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
