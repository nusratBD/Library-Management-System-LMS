<?php include 'header.php';


?>
<!-- content HEADER -->
<!-- ========================================================= -->
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><i aria-hidden="true"></i><a href="index.php">Profile</a></li>
            
        </ul>
        
    </div>
</div>
<!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
<div class="row animated fadeInUp">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b><li class="fa fa-user"></li> My Profile</b></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                   <div class="row">
    <div class="col-sm-7">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name : </th>
                    <td><?php echo ucwords($row['fname'].' '.$row['lname']);?></td>
                    
                </tr>

                <tr>
                    <th>Username : </th>
                    <td><?php echo $row['username'];?></td>
                </tr>

                <tr>
                    <th>Email : </th>
                    <td><?php echo $row['email'];?></td>
                </tr>

                <tr>
                    <th>Phone : </th>
                    <td><?php echo $row['phone'];?></td>
                </tr>

                <tr>
                    <th>SignUp Date: </th>
                    <td><?php echo $row['date'];?></td>
                </tr>
            </thead>
        </table>
        
        <a href="profile_update.php?id=<?php echo base64_encode($row['id']);?>" class="btn btn-primary btn-sm pull-right">Edit Profile</a>
    </div>
    <div class="col-sm-5">
        <a href="#">
            <img src="../image/student/<?php echo $row['photo']?>" style="width: 100%; height: 250px;" class="img-thumbnail">
        </a>
        <br>
<!-------------------Update User Profile Pic------------------->
        <?php
        $username = $row['username'];
            if (isset($_POST['upload'])) {



    //........Replace Photoname by Username.............

    //1)Breaking Username toward the dot(.) point
    $photo = explode('.',$_FILES['pp']['name']);

    //2)Taking the extantion of the photo, like- png/jpg/jpeg
    $photo = end($photo);
        
    //3)Add username, dot(.) and extantion and complete the photo name 
    $photo_name = $username.".".$photo;

    //Run Update Query:
    $upload = mysqli_query($con, "UPDATE `student` SET `photo`='$photo_name' WHERE username = '$username' ");

    //upload successful হলে computer এ ফটো টি সেভ হবেঃ 
        if ($upload) {
            move_uploaded_file($_FILES['pp']['tmp_name'], '../image/student/'.$photo_name);
            
        }
            }
        ?>
            
        <form action="" method="POST" enctype="multipart/form-data">
            
    <label><strong>Update Profile Pic</strong></label><br>
                <input type="file" name="pp">
                <input type="submit" name="upload" value="Upload" class="btn btn-primary btn-sm pull-right">
            </form>
    </div>
                </div>
            </div>
        </div>
    </div>
    
</div>
</div>
<?php include 'footer.php';?>