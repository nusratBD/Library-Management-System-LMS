<?php
include'../dbcon.php';

$id = base64_decode($_GET['id']);

//$student_id এর Dataগুলো Database থেকে SELLECT করাঃ
$db_data = mysqli_query($con, "SELECT * FROM `student` WHERE `id`='$id'");

//Table row থেকে Data বের করে আনাঃ যেহেতু single row এর Data বের করে আনব, তাই আর loop চালাতে হবে না।
$row = mysqli_fetch_assoc($db_data);



if (isset($_POST['update_student'])) {

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
//Form Validation:
if (strlen($username)>'7') {

}
else{
$username_l = "";
}


//02)Update Query:
$query = "UPDATE `student` SET `fname`='$fname',`lname`='$lname',`username`='$username',`email`='$email',`phone`='$phone' WHERE `id`= '$id' ";


//03)Update Query Run করাঃ
$result = mysqli_query($con, $query);



//04)যদি query run হয়, তাহলে নিচের কাজগুলো হবেঃ
if ($result) {
	

	header('Location: profile.php');
}

}
include 'header.php';
?>
<!------------------Student Add Form------------------>
<div class="content-header">
	<!-- leftside content header -->
	<div class="leftside-content-header">
		<ul class="breadcrumbs">
			<li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
			<li><i aria-hidden="true"></i><a href="index.php">Update Profile</a></li>
			
		</ul>
		
	</div>
</div>
<!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
<div class="row animated fadeInUp">
	<div class="col-sm-12">
		<h4 class="section-subtitle"><b><li class="fa fa-user"></li> Update Student Profile</b></h4>
		<div class="panel">
			<div class="panel-content">
				<div class="row">
					<div class="col-sm-5 col-sm-offset-3">
						<form action="" method="POST">
							<!--Form এ set করা Data গুলো value হিসেবে show করানো--->
							<div class="form-group">
								<label for="fname">First Name:</label>
								<input type="text" name="fname" id="fname" class="form-control" placeholder="Student Name" value="<?=$row['fname']?>">
							</div>
							<div class="form-group">
								<label for="lname">Last Name:</label>
								<input type="text" name="lname" id="lname" class="form-control" placeholder="Student Name" value="<?=$row['lname']?>">
							</div>
							<div class="form-group">
								
								<label for="username">Username:</label>
								<?php
								
								//...........Username more than 8 Character Error Message.........
								if (isset($username_l)) {
								
								echo '<span style="color:red;text-align:center;">'."Username more than 8 Character!".'</span>';
								} ?>
								<input type="text" name="username" id="username" class="form-control" required=""value="<?=$row['username']?>">
							</div>
							<div class="form-group">
								<label for="email">Email:</label>
								<input type="email" name="email" id="email" class="form-control" required=""value="<?=$row['email']?>">
							</div>
							
							<div class="form-group">
								<label for="phone">Phone:</label>
								<input type="text" name="phone" id="phone" class="form-control"  pattern="01[1|3|5|6|7|8|9][0-9]{8}" required="" value="<?=$row['phone']?>">
							</div>
							
							
							<div class="form-group">
								<input type="submit" name="update_student" value="Update Profile" class="btn btn-primary pull-right">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	
</div>
</div>
<?php
include 'footer.php';
?>