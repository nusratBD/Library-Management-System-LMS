<?php include 'header.php';
?>
<!-- content HEADER -->
<!-- ========================================================= -->
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            
        </ul>
        
    </div>
</div>
<!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
<div class="row animated fadeInUp">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b><li class="fa fa-book"></li> All Issued Books</b></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Book Name</th>
                                <th>Book Image</th>
                                <th>Issue Date</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php 

                            $student_id = $_SESSION['student_id'];
                            $result = mysqli_query($con,"SELECT `issue_book`.`issue_date`, `book`.`book_name`, `book`.`book_image`
                            FROM `book`
                            INNER JOIN `issue_book` ON `issue_book`.`book_id`=`book`.`id`
                            WHERE `issue_book`.`student_id`='$student_id'");
                            while ($row = mysqli_fetch_assoc($result))
                             {
                                ?>
                                <tr>
                                <td><?php echo ucwords($row['book_name']);?></td>
                                <td><img src="../image/book/<?php echo $row['book_image'];?>" style="height: 70px; width: 55px;"></td>
                                <td><?php echo date('d-M-Y',strtotime($row['issue_date'])) ;?></td>
                            </tr>
                             <?php    
                             } ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
</div>
</div>
<?php include 'footer.php';?>