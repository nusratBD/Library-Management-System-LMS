<?php include 'header.php';?>
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><a href="test.php">All Books</a></li>
        </ul>
        
    </div>
</div>
<!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
<form method="POST">
    <div class="row pt-md">
        <div class="form-group col-sm-9 col-lg-10">
            <span class="input-with-icon">
                <input type="text" name = "result_book" class="form-control" id="lefticon" placeholder="Search" required="">
                <i class="fa fa-search"></i>
            </span>
        </div>
        <div class="form-group col-sm-3  col-lg-2 ">
            <button type="submit" name = "search_book" class="btn btn-primary btn-block">Search</button>
        </div>
    </div>
</form>
<?php if(isset($_POST['search_book'])){
    $book_result = $_POST['result_book'];
    ?>


<div class="row animated fadeInUp">
    <div class="col-sm-12">
        <div class="panel">
            <div class="panel-content">
                <div class="row">
                     <?php 
    $result = mysqli_query($con,"SELECT * FROM `book` WHERE `book_name`LIKE '%$book_result%';");
                    $book_empty = mysqli_num_rows($result);
                    if ($book_empty=='0') { ?>
                        <h1><center>Book Not Found.</center></h1>
                     <?php    
                    }

                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-sm-3 col-md-2">
                        <img src="../image/book/<?php echo $row['book_image'];?>" style="height: 200px; width: 150px;">
                        <p>Name: <?php echo $row['book_name'];?></p>
                        <span><strong>Available: <?php echo $row['available_quantity'];?> </strong></span>
                    </div>
                    <?php
                    }
                }
                    else {
                    ?>
                    <?php
                    $result = mysqli_query($con,"SELECT * FROM `book` ");
                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-sm-3 col-md-2">
                        <img src="../image/book/<?php echo $row['book_image']?>" style="height: 120px; width: 90px;">
                        <p>Name: <?php echo $row['book_name']?></p>
                        <span><strong>Available: <?php echo $row['available_quantity']?> </strong></span>
                    </div>
                    <?php
                    }
                }
                    ?>
                </div>
            </div>
        </div>
    </div>
    
</div>
</div>
<?php include 'footer.php';?>
