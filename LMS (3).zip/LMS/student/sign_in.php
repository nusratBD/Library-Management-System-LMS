<?php
include '../dbcon.php';
session_start();
if (isset($_SESSION['student_signin'])) {
    header('Location:index.php');
}
//=>Taking User input:
if (isset($_POST['sign_in'])) {
$email = $_POST['email'];
$password = md5($_POST['password']);
//=>Form Validation and login:
$email_check = mysqli_query($con, "SELECT * FROM student WHERE email = '$email' OR username = '$email';");
if (mysqli_num_rows($email_check)=='1') {
$row = mysqli_fetch_assoc($email_check);
if ($row['password'] == $password) {


if ($row['status'] == '1') {

$_SESSION['student_signin'] = $email;
$_SESSION['student_id'] = $row['id'];

header('Location:index.php');
}
else{
$status_error = "";
}
}
else{
$password_error = "";
}
}
else{
$email_error = "";
}
}
?>
<!DOCTYPE html>
<html lang="en" class="fixed accounts sign-in">
    <!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:05:33 GMT -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>LMS</title>
        
        <!--BASIC css-->
        <!-- ========================================================= -->
        <link rel="stylesheet" href="../file/vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="../file/vendor/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="../file/vendor/animate.css/animate.css">
        <!--SECTION css-->
        <!-- ========================================================= -->
        <!--TEMPLATE css-->
        <!-- ========================================================= -->
        <link rel="stylesheet" href="../file/stylesheets/css/style.css">
    </head>
    <body>
        <div class="wrap">
            <!-- page BODY -->
            <!-- ========================================================= -->
            <div class="page-body animated slideInDown">
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
                <!--LOGO-->
                <div class="logo text-center">
                    <h1>LMS</h1>
                    <?php
                    if(isset($email_error))
                    echo '<div class="alert alert-warning text-center" role="alert">'."Invalid Email or Username. Please Try with right one.".'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>';
                    if(isset($password_error))
                    echo '<div class="alert alert-warning text-center" role="alert">'."Wrong Password.".'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>';
                    if(isset($status_error))
                    echo '<div class="alert alert-warning text-center" role="alert">'."Account inactive. Please contact with the Librarian".'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button></div>';
                    ?>
                </div>
                <div class="box">
                    <!--SIGN IN FORM-->
                    <div class="panel mb-none">
                        <div class="panel-content bg-scale-0">
                            <form method="POST" action="">
                                <div class="form-group mt-md">
                                    <span class="input-with-icon">
                                        <input type="text" class="form-control" name="email" placeholder="Email or Username" value="<?php if(isset($email))
                                        echo $email;?>">
                                        <i class="fa fa-envelope"></i>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <span class="input-with-icon">
                                        <input type="password" class="form-control" name="password" placeholder="Password">
                                        <i class="fa fa-key"></i>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <div class="checkbox-custom checkbox-primary">
                                        <input type="checkbox" id="remember-me" value="option1" checked>
                                        <label class="check" for="remember-me">Remember me</label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-primary btn-block" value="Sign in" type="submit" name="sign_in">
                                </div>
                                <div class="form-group text-center">
                                    <a href="pages_forgot-password.html">Forgot password?</a>
                                    <hr/>
                                    <span>Don't have an account?</span>
                                    <a href="register.php" class="btn btn-block mt-sm">Register</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
            </div>
        </div>
        <!--BASIC scripts-->
        <!-- ========================================================= -->
        <script src="../file/vendor/jquery/jquery-1.12.3.min.js"></script>
        <script src="../file/vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="../file/vendor/nano-scroller/nano-scroller.js"></script>
        <!--TEMPLATE scripts-->
        <!-- ========================================================= -->
        <script src="../file/javascripts/template-script.min.js"></script>
        <script src="../file/javascripts/template-init.min.js"></script>
        <!-- SECTION script and examples-->
        <!-- ========================================================= -->
    </body>
    <!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_sign-in.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:05:37 GMT -->
</html>