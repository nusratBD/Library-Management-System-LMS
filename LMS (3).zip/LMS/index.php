<!DOCTYPE html>
<html>
<head>
	<title>LMS</title>
	<link rel="stylesheet" type="text/css" href="file/vendor/bootstrap/css/bootstrap.css">
</head>
<body>
		<br><br>
		<div class="row">
			<div class="col-sm-4 col-sm-offset-4">
				<a href="student" class="btn btn-danger btn-block">Student</a><br>
				<a href="librarian" class="btn btn-danger btn-block">Librarian</a><br>
			</div>
		</div>
		
		>
</body>
</html>