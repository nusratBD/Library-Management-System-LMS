<?php include 'header.php';
?>
<!-- content HEADER -->
<!-- ========================================================= -->
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><a href="manage_book.php">Manage Books</a></li>
        </ul>
        
    </div>
</div>
<!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
<div class="row animated fadeInUp">
    <div class="col-sm-12">
        <h4 class="section-subtitle"><b><li class="fa fa-book"></li> Books</b></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="table-responsive">
                    
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Book Name</th>
                                <th>Book Image</th>
                                <th>Author Name</th>
                                <th>Publication Name</th>
                                <th>Purchase Date</th>
                                <th>Book Price</th>
                                <th>Book Quantity</th>
                                <th>Available Quantity</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT * FROM `book`";
                            $result = mysqli_query($con,$sql);
                            
                            while($row = mysqli_fetch_assoc($result)){?>
                            <tr>
                                <td><?php echo ucwords($row['book_name']);?></td>
                                <td><img style="height: 70px; width: 50px;" src="../image/book/<?php echo $row['book_image']; ?>"></td>
                                <td><?php echo ucwords($row['book_author_name']);?></td>
                                <td><?php echo ucwords($row['book_publication_name']);?></td>
                                <td><?php echo $row['book_purchase_date'];?></td>
                                <td><?php echo $row['book_price'];?></td>
                                <td><?php echo $row['book_quantity'];?></td>
                                <td><?php echo $row['available_quantity'];?></td>
                                <td><a href="javascript: avoid(0)" class="btn btn-primary" data-toggle="modal" data-target="#book-<?php echo $row['id'] ?>"><i class="fa fa-eye"></i></a></td>
                                <td><a href="" class="btn btn-info" data-toggle="modal" data-target="#book-update-<?php echo $row['id'] ?>"><i class="fa fa-pencil"></i></a></td>
                                <td><a href="delete.php?bookdelete=<?php echo base64_encode($row['id']);?>" class="btn btn-danger" onclick = "return confirm('Are you sure to delete?')"><i class="fa fa-trash"></i></a></td>
                                
                            </tr>
                            <?php }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
</div>
<!------------------------------------View Book----------------------------------->
<?php
$sql = "SELECT * FROM `book`";
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_assoc($result)){?>
<div class="modal fade" id="book-<?php echo $row['id']?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="modal-info-label"><i class="fa fa-book"></i>Book Info</h4>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Book Name</th>
                        <td><?php echo ucwords($row['book_name']);?></td>
                    </tr>
                    <tr>
                        <th>Book Image</th>
                        <td><img style="height: 80px; width: 70px;" src="../image/book/<?php echo $row['book_image']; ?>"></td>
                    </tr>
                    <tr>
                        <th>Author Name</th>
                        <td><?php echo ucwords($row['book_author_name']);?></td>
                    </tr>
                    <tr>
                        <th>Publication Name</th>
                        <td><?php echo ucwords($row['book_publication_name']);?></td>
                    </tr>
                    <tr>
                        <th>Purchase Date</th>
                        <td><?php echo $row['book_purchase_date'];?></td>
                    </tr>
                    <tr>
                        <th>Book Price</th>
                        <td><?php echo $row['book_price'];?></td>
                    </tr>
                    <tr>
                        <th>Book Quantity</th>
                        <td><?php echo $row['book_quantity'];?></td>
                    </tr>
                    <tr>
                        <th>Available Quantity</th>
                        <td><?php echo $row['available_quantity'];?></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
                
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php }?>
<!-----------------------------------Update Book------------------------------------>
<?php
$sql = "SELECT * FROM `book`";
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_assoc($result)){
$id = $row['id'];
$book_info = mysqli_query($con, "SELECT * FROM `book` WHERE id = '$id'");
$book_row = mysqli_fetch_assoc($book_info);
?>
<div class="modal fade" id="book-update-<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="modal-info-label"><i class="fa fa-book"></i> Update Book Info</h4>
            </div>
            <div class="modal-body">
                <div class="panel">
                    <div class="panel-content">
                        <div class="row">
                            <div class="col-md-12">
                                <form method="POST" action="">
                                    
                                    <div class="form-group">
                                        <label for="name" class=" control-label">Book Name</label>
                                         <input type="hidden" class="form-control"  name="id" required="" value="<?php echo $book_row['id'];?>">
                                        
                                        <input type="text" class="form-control" id="name"  name="book" required="" value="<?php echo $book_row['book_name'];?>">
                                        
                                    </div>
                                    <div class="form-group">
                                        <img src="../image/book/<?php echo $book_row['book_image'];?>" style="height: 70px; width: 50px;">
                                        
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="author" class=" control-label">Author Name</label>
                                        
                                        <input type="text" class="form-control" id="author"  name="author_name" required="" value="<?php echo $book_row['book_author_name'];?>">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="publication" class=" control-label">Publication Name</label>
                                        
                                        <input type="text" class="form-control" id="publication" name = "publication_name" required="" value="<?php echo $book_row['book_publication_name'];?>">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="pdate" class=" control-label">Purchase Date</label>
                                        
                                        <input type="date" class="form-control" id="pdate"  name="purchase_date" required="" value="<?php echo $book_row['book_purchase_date'];?>">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="price" class=" control-label">Book Price</label>
                                        
                                        <input type="number" class="form-control" id="price"  name="book_price" required="" value="<?php echo $book_row['book_price'];?>">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="quantity" class=" control-label">Book Quantity</label>
                                        
                                        <input type="number" class="form-control" id="quantity"  name="book_quantity" required="" value="<?php echo $book_row['book_quantity'];?>">
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="available" class=" control-label">Available Quantity</label>
                                        
                                        <input type="number" class="form-control" id="available"  name="available_quantity" required="" value="<?php echo $book_row['available_quantity'];?>">
                                        
                                    </div>
                                    
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary" name="update_book"><i class="fa fa-save" ></i> Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php
}

if (isset($_POST['update_book'])) {
$id = $_POST['id'];
$book_name = $_POST['book']; 

$author_name = $_POST['author_name']; 
$publication_name = $_POST['publication_name'];
$purchase_date = $_POST['purchase_date']; 
$book_price =$_POST['book_price'];
$book_quantity = $_POST['book_quantity'];
$available_quantity = $_POST['available_quantity'];




$query = "UPDATE `book` SET `book_name`= '$book_name',`book_author_name`='$author_name',`book_publication_name`= '$publication_name',`book_purchase_date`= '$purchase_date',`book_price`= '$book_price',`book_quantity`= '$book_quantity',`available_quantity`= '$available_quantity' WHERE `id`='$id'";
$result = mysqli_query($con,$query);
 if ($result) { ?>
        <script type="text/javascript">
            alert('Book Issued Successfully!');
        </script>
    <?php     
    }else{
        ?>
      <script type="text/javascript">
            alert('Book Not Issued.Try Again!');
        </script> 
    <?php  
    }

}


?>
<?php include 'footer.php';?>